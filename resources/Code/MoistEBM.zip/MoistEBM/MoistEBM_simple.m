function sol = MoistEBM_simple(param,pp_lambda,pp_tref,pp_r,pp_forcing)
%
%   MoistEBM_simple.m
%
%   A linear diffusive EBM for perturbations from a reference climate
%  accounting for spatially varying radiative feedback and diffusion of
%  moist static energy
%
%  No ice albedo explicitly included
%
%  October 7 2013
%
%  See Rose et al. (2014) "The dependence of transient climate sensitivity 
%    and radiative feedbacks on the spatial pattern of ocean heat uptake"
%  Geophysical Research Letters vol. 41
%
%  There are switches to use fitted values of reference temperature, 
%   reference relative humidty, local feedback, and CO2 radiative forcing
%  Accompanying .mat files contain cubic spline fits to the zonal mean
%  values from the CAM4 simulations as described in Rose et al. (2014)
%
%  See the accompanying driver script for examples of how to call the EBM
%
%  cleaned up for public distribution 
%  September 2014
%  
%   Brian Rose,  brose@albany.edu
%   University at Albany

a = 6.373E6;  % radius of Earth
K = 0.24;  %  specified diffusion constant in W/m^2/K (actually K/a in notation of Rose et al. (2014)
L = 2.5E6; % Latent heat of vaporization
cp = 1E3;  % specific heat at constant pressure
rfixed = 0.8;   % fixed relative humidity
Aup = 2;  %  specified ocean heat uptake in W/m^2

exp = param.exp;
if nargin==1
lambda0 = param.lambda(1);
if length(param.lambda>1)
    lambda2 = param.lambda(2);
else
    lambda2 = 0;
end
    usefittedlambda = false;
else
    usefittedlambda = true;
end
if nargin>2
    usefittedtref = true;
else
    usefittedtref = false;
end
if nargin>3
    usefittedr = true;
else
    usefittedr = false;
end

%  The EBM is solved using MATLAB boundary value problem solver bvp4c
xinit = linspace(-0.99999,0.99999);
solinit = bvpinit(xinit,@EBMinit);
sol = bvp4c(@EBMequation,@EBMbc,solinit);

%  some post-processing: evaluate a few different aspects of the solution
sol.param = param;
sol.lat = asin(sol.x)*180/pi;
[f,dqsatdT] = computef(sol.x);
sol.dqsatdT = dqsatdT; sol.f = f;
sol.T = sol.y(1,:)./(1+sol.f); % temperature anomaly
sol.R = forcing(sol.x);  %  forcing in W/m^2
if usefittedlambda
    sol.lambda = -ppval(pp_lambda,sol.x);
else
    sol.lambda = lambda0+lambda2.*P2(sol.x);
end
sol.Tbar = trapz(sol.x,sol.T)/2;  % global mean temperature anomaly
sol.H = -2*pi*a.^2.*K.*sol.y(2,:)*1E-15; % poleward heat transport in PW
sol.polar = sol.T(end)./sol.Tbar;  % ratio of polar change to global mean change
sol.Rbar = trapz(sol.x,sol.R)/2;  % global mean forcing
sol.lambdaG = sol.Rbar/sol.Tbar;  % global mean feedback
sol.Tref = Tref(sol.x);  % reference temperature

    function dydx = EBMequation(x,y)
        % The EBM equation coded up as a system of 2 first order ODEs.
        R = forcing(x);
        f = computef(x);
        %f = zeros(size(x));
        if usefittedlambda
            lambda = -ppval(pp_lambda,x);
        else
            lambda = lambda0+lambda2.*P2(x);
        end
       dydx = [1./(1-x^2).*y(2); lambda./K./(1+f).*y(1) - R./K];
    end
    function res = EBMbc(ya,yb)
        %  Boundary conditions:  flux = 0 on both boundaries (poles)
        res = [  ya(2)
            yb(2)]; 
    end
    function yinit = EBMinit(x)
        yinit = [  -ones(size(x))
            zeros(size(x)) ];
    end  
    function [f,dqsatdT] = computef(x)
        if (usefittedtref)
            thisTref = ppval(pp_tref,x);
        else
            thisTref = Tref(x);
        end
        dqsatdT = (qsat(thisTref+0.1,1000)-qsat(thisTref-0.1,1000))/0.2;
        if (usefittedr)
            r = ppval(pp_r,x);
        else
            r = rfixed;
        end
        f = r*L/cp.*dqsatdT;
        %f = zeros(size(x));
    end
    function T = Tref(x)
        T = 288*(1-0.1/2*(3*x.^2-1));
    end
    function R = forcing(x)
        switch exp
            case 'qupH'
                R = min(0,-299/90./cos(2*pi/9).*Aup.*sin(18/5*(abs(asin(x))-2*pi/9)));
            case 'qupT'
                R = min(0,-16/3/sqrt(3).*Aup.*cos(3*asin(x)));
            case 'const+qupH'
                R = Aup+min(0,-299/90./cos(2*pi/9).*Aup.*sin(18/5*(abs(asin(x))-2*pi/9)));
            case 'const+qupT'
                R = Aup+min(0,-16/3/sqrt(3).*Aup.*cos(3*asin(x)));
            case 'const'
                %R = Aup*ones(size(x));
                R = 3.7*ones(size(x));
            case 'CO2forcing'
                R = ppval(pp_forcing,x);
        end
    end
    function p2 = P2(x)
        p2 = 1/2.*(3.*x.^2-1);
    end
end