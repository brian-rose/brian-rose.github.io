function es = ClausiusClapeyron(T)
%
%  an approximate formula for saturation vapor pressure (in mb or hPa)
%  as function of temperature T (in Kelvin)
%
%  Rogers and Yau "A Short Course in Cloud Physics", p. 16
%   claimed to be accurate to within 0.1% between -30degC and 35 degC
%  Based on the paper by Bolton (1980 MWR)
%
%   Brian Rose
%   August 20, 2010

Tcel = T-273.15;

es = 6.112*exp(17.67*Tcel./(Tcel+243.5));