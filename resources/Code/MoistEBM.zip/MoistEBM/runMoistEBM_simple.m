%   runMoistEBM_simple.m
%
%  A script to run the simple Moist EBM with diffusion on moist static energy
%  and spatially varying feedback
%
%  Rose et al. (2014) "The dependence of transient climate sensitivity 
%    and radiative feedbacks on the spatial pattern of ocean heat uptake"
%  Geophysical Research Letters vol. 41
%
%   To reproduce Fig. 4 from Rose et al. (2014), just run the final block
%   of code below.
%
%   There are several other examples of different ways to the solve the EBM
%   included here. See the comments inline.
%
%  cleaned up for public distribution 
%  September 2014
%  
%   Brian Rose,  brose@albany.edu
%   University at Albany


%  This code just assigns an analytical P2(x) form for the feedback
%   lambda, so there is a parameter that sets the strength of meridional 
%   feedback variations. The code loops over that parameter, solves the
%   model each time for three different kinds of forcing, and then makes
%   some plots.
lambda0 = 4;
lambda2array = linspace(-4,4,21);

for l=1:length(lambda2array)
    param.lambda = [lambda0 lambda2array(l)];
    display(['lambda_2 = ' num2str(lambda2array(l))])
    param.exp = 'const';
    solarray_const(l) = MoistEBM_simple(param);
    param.exp = 'qupH';
    solarray_qupH(l) = MoistEBM_simple(param);
    param.exp = 'qupT';
    solarray_qupT(l) = MoistEBM_simple(param);
    lambdaGarray_const(l) = solarray_const(l).lambdaG;
    lambdaGarray_qupH(l) = solarray_qupH(l).lambdaG;
    lambdaGarray_qupT(l) = solarray_qupT(l).lambdaG;
    Tbararray_const(l) = solarray_const(l).Tbar;
    Tbararray_qupH(l) = solarray_qupH(l).Tbar;
    Tbararray_qupT(l) = solarray_qupT(l).Tbar;
    polararray_const(l) = solarray_const(l).polar;
    polararray_qupH(l) = solarray_qupH(l).polar;
    polararray_qupT(l) = solarray_qupT(l).polar;
end
figure
subplot(2,1,1)
plot(lambda2array,[lambdaGarray_const;lambdaGarray_qupH;lambdaGarray_qupT],'LineWidth',2)
grid on; box on;
set(gca,'FontSize',16)
xlabel('lambda2')
ylabel('lambdaG')
legend('CO2','qupH','qupT')
subplot(2,1,2)
plot(lambda2array,[polararray_const;polararray_qupH;polararray_qupT],'LineWidth',2)
set(gca,'FontSize',16)
xlabel('lambda2')
ylabel('polar amplification')
legend('CO2','qupH','qupT')
grid on; box on;


%  This code explores a wider range of feedbacks by varying both parameters
%  that control the magnitude and spatial structure of lambda
%    THIS WILL TAKE A WHILE TO RUN.
exparray = {'const','qupH','qupT'};
lambda2array = linspace(-4,4,11);
lambda0array = linspace(0.1,8,15);
param.exp = 'const'; param.lambda = [2 0]; testsol = MoistEBM_simple(param);
sz = [length(lambda0array),length(lambda2array),length(exparray)];
solarray = repmat(testsol,sz);
lambdaGarray = zeros(sz); Tbararray = zeros(sz); polararray = zeros(sz); 
for l0 = 1:length(lambda0array)
    display(['lambda_0 = ' num2str(lambda0array(l0))])
    for l2 = 1:length(lambda2array)
        param.lambda = [lambda0array(l0),lambda2array(l2)];
        for exp=1:length(exparray)
            param.exp = exparray{exp};
            solarray(l0,l2,exp) = MoistEBM_simple(param);
            lambdaGarray(l0,l2,exp) = solarray(l0,l2,exp).lambdaG;
            Tbararray(l0,l2,exp) = solarray(l0,l2,exp).Tbar;
            polararray(l0,l2,exp) = solarray(l0,l2,exp).polar;
        end
    end
end
figure
for i=1:length(exparray)
    subplot(3,1,i)
    [c,h] = contourf(lambda0array,lambda2array,lambdaGarray(:,:,i)',0:10);
    clabel(c,h)
    xlabel('lambda_0'); ylabel('lambda_2')
    title(exparray{i})
    colorbar
end


%  This code uses the tuned lambda(x) profiles from the CAM4 GCM
%  simulations (Rose et al. 2014)
%   It computes solutions for several forcings and plots the temperature
%   anomalies versus latitude
%  Needs data file pp_lambda.mat, contains cubic spline fit for lambda
load pp_lambda.mat
param.exp = 'const';
sol_const = MoistEBM_simple(param,pp_CO2);
param.exp = 'qupH';
sol_qupH = MoistEBM_simple(param,pp_qupH);
sol_qupH_co2lambda = MoistEBM_simple(param,pp_CO2);
param.exp = 'qupT';
sol_qupT = MoistEBM_simple(param,pp_qupT);
sol_qupT_co2lambda = MoistEBM_simple(param,pp_CO2);
figure
hold on
plot(sol_const.lat,sol_const.T,sol_qupH.lat,sol_qupH.T,sol_qupT.lat,sol_qupT.T,'LineWidth',2)
plot(sol_const.lat,sol_const.T,sol_qupH_co2lambda.lat,sol_qupH_co2lambda.T,...
    sol_qupT_co2lambda.lat,sol_qupT_co2lambda.T,'LineWidth',1,'LineStyle','--')
hold off
set(gca,'FontSize',16,'XLim',[-90 90],'XTick',-90:30:90)
grid on
xlabel('Latitude')
ylabel('T^\prime')
legend('CO2','qupH','qupT')


%  This code uses fits for lamda, reference temperature, reference
%  relative humidity, and CO2 radiative forcing.
%  Solves the model for various forcings, and
%   Reproduces Fig. 4 from Rose et al. (2014)

load pp_lambda.mat
load pp_tref.mat
load pp_CO2forcing.mat
load pp_r.mat

param.exp = 'CO2forcing';
sol_CO2 = MoistEBM_simple(param,pp_CO2,pp_tref,pp_r,pp_CO2forcing);
param.exp = 'qupH';
sol_qupH = MoistEBM_simple(param,pp_qupH,pp_tref,pp_r);
sol_qupH_co2lambda = MoistEBM_simple(param,pp_CO2,pp_tref,pp_r);
param.exp = 'qupT';
sol_qupT = MoistEBM_simple(param,pp_qupT,pp_tref,pp_r);
sol_qupT_co2lambda = MoistEBM_simple(param,pp_CO2,pp_tref,pp_r);

pos = [100,100,500,350];
figure('OuterPosition',pos)
hold on
plot(sol_CO2.lat,sol_CO2.T,sol_qupH.lat,sol_qupH.T,sol_qupT.lat,sol_qupT.T,'LineWidth',3)
plot(sol_CO2.lat,sol_CO2.T,sol_qupH_co2lambda.lat,sol_qupH_co2lambda.T,...
    sol_qupT_co2lambda.lat,sol_qupT_co2lambda.T,'LineWidth',2,'LineStyle','--')
hold off
set(gca,'FontSize',16,'XLim',[-90 90],'XTick',-90:30:90)
grid on
xlabel('Latitude')
ylabel('T')
legend('CO2','qupH','qupT')
