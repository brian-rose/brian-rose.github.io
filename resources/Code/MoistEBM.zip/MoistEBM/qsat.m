function q = qsat(T,p)
%
%  Compute saturation specific humidity 
%   This calls a routine that computes saturation vapor pressure
%   using an accurate interpolation.
%
%  q = qsat(T,p)
% 
%  T is temperature in K, p is pressure in hPa or mb.
%
%  Brian Rose
%  Feb. 2013
%

eps = 0.622;  % ratio of dry air gas constant / water vapor gas constant
es = ClausiusClapeyron(T);  % saturation vapor pressure in hPa
q = eps*es./(p-(1-eps).*es);  % computes saturation specific humidity